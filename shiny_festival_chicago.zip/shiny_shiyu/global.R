# for fullPage:
# install.packages("remotes")
# remotes::install_github("RinteRface/fullPage")
library(fullPage)
library(leaflet)
library(RPostgres)
library(scales)
library(shiny)
library(shinyalert)
library(shinyWidgets)
library(tidyverse)

# connect to the project database---- shiyu 
con <- dbConnect(
  drv = dbDriver('Postgres'),
  dbname = 'fest8',
  host = 'db-postgresql-nyc1-44203-do-user-8018943-0.b.db.ondigitalocean.com',
  port = 25060,
  user = 'proj22b_8',
  password = 'AVNS_4JKVJgNCqiM4cVZf-Hu',
  sslmode = 'require'
)

arts <- dbGetQuery(con, 'SELECT * FROM arts;')
vens <- dbGetQuery(con, 'SELECT * FROM venues JOIN locations USING (locn_id);')
hots <- dbGetQuery(con, 'SELECT * FROM hotels JOIN locations USING (locn_id);')
ress <- dbGetQuery(con, 'SELECT * FROM resturants JOIN locations USING (locn_id);')  #name problem 
atts <- dbGetQuery(con, 'SELECT * FROM attractions JOIN locations USING (locn_id);')

# when exiting app, disconnect from the paris database
onStop(
  function()
  {
    dbDisconnect(con)
  }
)