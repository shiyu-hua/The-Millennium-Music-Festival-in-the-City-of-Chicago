server <- function(input, output, session) {
  
  # reactive values----
  a <- reactiveValues(
    rt = NULL, # artist number (1-15)
    fd = NULL, # festival day (1-3)
    mn = NULL, # member number (1-7)
    ex = NULL, # experience option (1-3)
  )
  
  # ui art1---- 
  output$uiArt1 <- renderUI(
    {
      div(
        style = 'padding:0 10% 0 10%;',
        lapply(
          0:2, 
          function(i) {
            wellPanel(
              style = 'background-color:rgba(250,250,250,0.5);',
              fluidRow(
                column(
                  width = 2,
                  style = 'padding-top:5vh;',
                  actionBttn(
                    inputId = paste0('day', i+1),
                    label = (c('Feel the Blues @ Friday', 
                               'Rap all Night @ Saturday' , 
                               'Rock & Roll @ Sunday')[i+1]),   
                    style = 'stretch', 
                    color = 'royal',  
                    size = 'lg'  
                  )
                ),
                lapply(
                  1:5, 
                  function(j) {
                    column(
                      width = 2,
                      fullButtonRight(
                        tags$button(
                          id = paste0('btnArt', 5*i+j),
                          class = 'btn action-button',
                          style = 'background-color:rgba(0,0,0,0);',
                          img(
                            src = paste0('artists/',arts$art_id[5*i+j],'.png'),
                            width = '80%' 
                          )
                        )
                      ),
                      h4(
                        style = 'margin-bottom:0;font-family:Rockwell',
                        arts$art_name[5*i+j]
                      )
                    )
                  }
                )
              )
            )
          }
        ),
        uiOutput('festTix')
      )
    }
  )
  
  # _events day button----
  observeEvent(input$day1, {a$fd <- 1})
  observeEvent(input$day2, {a$fd <- 2})
  observeEvent(input$day3, {a$fd <- 3})
  
  # _events artist button----
  observeEvent(input$btnArt1, {a$rt <- 1})
  observeEvent(input$btnArt2, {a$rt <- 2})
  observeEvent(input$btnArt3, {a$rt <- 3})
  observeEvent(input$btnArt4, {a$rt <- 4})
  observeEvent(input$btnArt5, {a$rt <- 5})
  observeEvent(input$btnArt6, {a$rt <- 6})
  observeEvent(input$btnArt7, {a$rt <- 7})
  observeEvent(input$btnArt8, {a$rt <- 8})
  observeEvent(input$btnArt9, {a$rt <- 9})
  observeEvent(input$btnArt10, {a$rt <- 10})
  observeEvent(input$btnArt11, {a$rt <- 11})
  observeEvent(input$btnArt12, {a$rt <- 12})
  observeEvent(input$btnArt13, {a$rt <- 13})
  observeEvent(input$btnArt14, {a$rt <- 14})
  observeEvent(input$btnArt15, {a$rt <- 15})
  
  # _ui fest tix----
  output$festTix <- renderUI(
    if (!is.null(a$fd)) {
      div(
        actionBttn(
          inputId = 'tix1',
          label = paste(
            'Buy',
            c('Friday', 'Saturday', 'Sunday')[a$fd],
            'Pass'
          ),
          style = 'material-flat', 
          color = 'warning', 
          size = 'md'
        ),
        actionBttn(
          inputId = 'tix3',
          label = 'Buy Full 3-Day Pass',
          style = 'material-flat', 
          color = 'danger', 
          size = 'md'
        )
      )
    }
  )
  
  # _events buy tix----
  observeEvent(input$tix1, {tixConf(1)})
  observeEvent(input$tix3, {tixConf(3)})
  
  # _function ticket confirm----
  tixConf <- function(d) {
    i <- if_else(d == 1, a$fd, 4)
    shinyalert(
      title = 'Thank you!',
      text = paste0(
        '<h3>You have purchased a pass for ',
        c('Friday night', 'Saturday night', 'Sunday night', 
          'all three nights')[i],
        '</h3>'
      ),
      showConfirmButton = TRUE,
      html = TRUE,
      type = 'success',
      closeOnClickOutside = TRUE
    )
  }
  
  # ui art2----
  output$uiArt2 <- renderUI(
    if (!is.null(a$rt)) {
      div(
        style = 'padding:0 10% 0 10%;',
        tags$iframe(
          height = '425px',
          width = '100%',
          style = 'border:5px solid white; border-radius:10px; margin-bottom:10px;',
          src = paste0(
            'https://www.youtube.com/embed/',
            arts$vid[a$rt]
          ),
          allow = 'fullscreen; autoplay;'
        ),
        fullButtonLeft(
          actionBttn(
            inputId = 'backArt1',
            label = 'Back',
            style = 'simple',
            color = 'warning',
            size = 'md',
            icon = icon('arrow-left')
          )
        )
      )
    }
  )
  
  # ui venue---- 
  output$uiVenue <- renderUI(
    {
      div(
        style = 'padding:0 10% 0 10%;',
        wellPanel(
          style = 'background-color:rgba(100,100,100,0.7);',
          fluidRow(
            column(
              width = 6,
              align = 'left',
              h4(
                style = 'color:white; line-height:1.5;',
                'The ',
                tags$span(
                  style = 'color:red; line-height:1.5;', 
                  'Jay Pritzker Pavilion ',
                  tags$span(
                    style = 'color:white; line-height:1.5;',
                    paste0(
                      'is one of the premier outdoor Amphitheatres in the Chicago. ',
                      'Located centrally in Millennium Park in the Loop community area of Chicago in Cook County, Illinois. ',
                      'The Pavilion itself offers an incredibly unique design, brought together by architect Frank Gehry. ',
                      'The Amphitheatre has a capacity of 11,000, offering a great atmosphere when seeing live shows! '
                    )
                  )
                )
              ),
              h4(
                style = 'color:white; line-height:1.5;',
                paste0(
                  'Millennium Park, which is conveniently located in the middle of the city and is easily accessible to all major hotels, ',
                  'restaurants, and transit hubs, is the ideal venue for your high-profile events because of its convenient position. ',
                  'The Pritzker Pavilion\'s stage, Wrigley Square, and the Rooftop Terrace are just a few of the many event locations ',
                  'that can be found throughout the park. You and your guests are urged to take use of the park\'s full range of offerings, ',
                  'from the event location itself to the artistic, architectural, and cultural delights that can be found around every corner.'
                )
              ),
              h4(
                style = 'color:white; line-height:1.5;',
                paste0(
                  'Entice yourself with an unforgettable celebration on the stage of the Jay Pritzker Pavilion, ',
                  'breathtaking views of the Chicago skyline from the Rooftop Terrace, ',
                  'or the convenience of being only steps away from Michigan Avenue on the Chase Promenades. '
                )
              )
            ),
            column(
              width = 6,
              leafletOutput('chicagoMap', height = '60vh')
            )
          )
        ),
        fullButtonLeft(
          actionBttn(
            inputId = 'backVen1',
            label = 'Back',
            style = 'simple',
            color = 'warning',
            size = 'md',
            icon = icon('arrow-left')
          )
        )
      )
    }
  )
  
  # _chicago map---- 
  output$chicagoMap <- renderLeaflet(
    {
      leaflet(
        data = vens
      ) %>%
        addProviderTiles(
          provider = providers$Esri.NatGeoWorldMap
        ) %>%
        addMarkers(
          lat = ~lat,
          lng = ~lng,
          popup = ~venue_name
        )
    }
  )

  # ui exper----
  output$uiExper <- renderUI(
    if (!is.null(a$ex)) {
      div(
        style = 'padding:0 10% 0 10%;',
        wellPanel(
          style = 'background-color:rgba(100,100,100,0.7);
                   padding-top:3px;',
          h2(
            style = paste0(
              'color:',
              switch(
                a$ex,
                'lightblue;',
                'lightgreen;',
                'lightpink;'
              )
            ),
            switch(
              a$ex,
              'Nearby Hotels',
              'Nearby Restaurants',
              'Nearby Attractions'
            )
          ),
          fluidRow(
            column(
              width = 8,
              leafletOutput('expMap', height = '60vh')
            ),
            column(
              width = 4,
              uiOutput('expList')
            )
          )
        ),
        fullButtonLeft(
          actionBttn(
            inputId = 'backExp1',
            label = 'Back',
            style = 'simple',
            color = 'warning',
            size = 'md',
            icon = icon('arrow-left')
          )
        )
      )
    }  
  )
  
  # _events exper button----
  observeEvent(input$hotels, {a$ex <- 1})
  observeEvent(input$rests,  {a$ex <- 2})
  observeEvent(input$attrs,  {a$ex <- 3})
  
  # _exp map----
  output$expMap <- renderLeaflet(
    {
      leaflet(
        data = switch(a$ex, hots[1:5,], ress[1:5,], atts[1:5,])
      ) %>%
        addProviderTiles(
          provider = providers$Esri.NatGeoWorldMap
        ) %>%
        addAwesomeMarkers(
          lng = ~lng,
          lat = ~lat,
          popup = ~switch(a$ex, hot_name, rest_name, attract_name),
          icon = awesomeIcons(
            markerColor = switch(a$ex, 'blue', 'green', 'red'),
            text = 1:5
          )
        ) %>%
        addMarkers(
          lat = vens$lat,
          lng = vens$lng,
          popup = vens$venue_name
        )
    }
  )
  
  # _exp list----
  output$expList <- renderUI(
    {
      lapply(
        1:5,
        function(i) {
          wellPanel(
            align = 'left',
            h4(
              paste0(
                i, ') ', 
                switch(a$ex,
                       hots$hot_name[i],
                       ress$rest_name[i],
                       atts$attract_name[i]),
                ' | Rating: ',
                switch(a$ex, 
                       hots$hot_rating[i],
                       ress$rating[i],
                       atts$attract_rating[i]),
                ' | ', 
                switch(a$ex,
                       ' ',
                       ress$rest_type[i],
                       'Price: '),
                switch(a$ex, 
                       ' ',
                       ' ',
                       atts$attract_price[i])
              )
            ),
            actionBttn(
              inputId = paste0('btnExp', i),
              label = tags$a(href= switch(a$ex, 
                                          hots$hot_website[i],
                                          ress$rest_website[i],
                                          ' '),
                             target="_blank",
                             switch(a$ex,
                             'Book a Room',
                             'Reserve a Table',
                             '')),     
              style = 'simple',
              color = switch(a$ex,
                             'default',
                             'default',
                             'default'),
              size = 'sm'
            )
          )
        }
      )
    }
  )
  
  # ui team----
  output$uiTeam <- renderUI(
    {
      div(
        style = 'padding:0 35% 0 35%;',
        lapply(
          1:6,
          function(i) {
            wellPanel(
              style = 'background-color:rgba(255,255,255,0.9); padding:3px;',
              fluidRow(
                column(
                  width = 4,
                  align = 'right',
                  img(
                    src = paste0(i, '.jpg'),
                    height = '60vh'
                  )
                ),
                column(
                  width = 8,
                  align = 'left',
                  style = 'padding-top:5px;',
                  actionBttn(
                    inputId = paste0('member', i),
                    label = paste0('Member ', i),
                    style = 'stretch',
                    color = c('primary', 'success', 'warning', 'danger', 'royal')[(i - 1) %% 5 + 1],
                    size = 'lg',
                    block = FALSE
                  )
                )
              )
            )
          }
        )
      )
    }
  )
  
  # _events member button----
  observeEvent(input$member1, {a$mn <- 1; memDet()})
  observeEvent(input$member2, {a$mn <- 2; memDet()})
  observeEvent(input$member3, {a$mn <- 3; memDet()})
  observeEvent(input$member4, {a$mn <- 4; memDet()})
  observeEvent(input$member5, {a$mn <- 5; memDet()})
  observeEvent(input$member6, {a$mn <- 6; memDet()})
  observeEvent(input$member7, {a$mn <- 7; memDet()})
  
  # _function member details----
  memDet <- function() {
    shinyalert(
      title = paste0('Member ', a$mn),
      text = paste0(
        '<h1>CEO</h1>',
        '<hr>',
        '<img src = "', a$mn, '.jpg" ',
        'width ="200px"></img>'
      ),
      showConfirmButton = TRUE,
      html = TRUE,
      closeOnClickOutside = TRUE
    )
  }
}
