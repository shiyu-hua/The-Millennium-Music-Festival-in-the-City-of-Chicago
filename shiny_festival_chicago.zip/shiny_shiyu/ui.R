ui <- fullPage(
  
  opts = list(
    controlArrows = FALSE,
    fadingEffect = TRUE,
    fitToSection = TRUE,
    loopBottom = FALSE,
    loopHorizontal = TRUE,
    navigation = FALSE,
    scrollBar = FALSE,
    scrollOverflow = TRUE,
    scrollOverflowReset = TRUE,
    slidesNavigation = TRUE,
    verticalCentered = TRUE
  ),
  
  # menu tabs----
  menu = c(
    'Welcome' = 'home',
    'Artist Lineup' = 'artists',
    'The Venue' = 'venue',
    'Plan the Stay' = 'exper',
    'About Us' = 'about'
  ),
  
  # home section----
  fullSectionImage(
    menu = 'home',
    center = TRUE,
    img = 'back.gif', 
    fullSlide(
      div(
        style = 'padding:0 15% 0 15%;',
        wellPanel(
          style = 'background-color:rgba(20,20,20,0.5); 
                   padding:15px; border-width:0;',
          fullButtonDown(
            img(
              src = 'logo.png',
              height = '180px',
            )
          ),
          h1(
            style = 'color:white; font-size:48px; font-family:Matura MT Script Capitals',
            'The Millennium Music Festival'
          ),
          hr(),
          div(
            style = 'padding:0 8% 0 8%;',
            fluidRow(
              column(
                width = 5,
                align = 'right',
                actionBttn(
                  inputId = 'sqlDts',
                  label = 'October 21-23, 2022',  
                  style = 'stretch',
                  color = 'default',
                  size = 'md'
                )
              ),
              column(
                width = 2,
                h5(style = 'color:white;','|')
              ),
              column(
                width = 5,
                align = 'left',
                actionBttn(
                  inputId = 'sqlDts',
                  label = 'Chicago, USA', 
                  style = 'stretch',
                  color = 'default',
                  size = 'md'
                )
              )
            )
          )
        )
      ),
      div(
        style = 'padding:20px 10% 0 10%;',
        fluidRow(
          column(
            width = 4,
            wellPanel(
              style = 'background-color:rgba(0,0,300,0.7); 
                       padding:10px; border-width:0;',
              h1(style = 'color:white;font-family:Magneto;font-size:42px', 
                 '15'),
              h4(style = 'color:white;font-family:Palatino Linotype;font-size:24px', 
                 'Greatest Artists')
            )
          ),
          column(
            width = 4,
            wellPanel(
              style = 'background-color:rgba(300,150,0,0.7); 
                       padding:10px; border-width:0;',
              h1(style = 'color:white;font-family:Magneto;font-size:42px', 
                 '3'),
              h4(style = 'color:white;font-family:Palatino Linotype;font-size:24px', 
                 'Nights')
            )
          ),
          column(
            width = 4,
            wellPanel(
              style = 'background-color:rgba(300,0,0,0.7); 
                       padding:10px; border-width:0;',
              h1(style = 'color:white;font-family:Magneto;font-size:42px', 
                 '1'),
              h4(style = 'color:white;font-family:Palatino Linotype;font-size:24px',
                 'Unforgettable Experience')
            )
          )
        )
      )
    )
  ),
  
  # artists section----  
  fullSectionImage(
    menu = 'artists',
    center = TRUE,
    img = 'pg_artist.jpg',
    fullSlide(
      uiOutput('uiArt1')
    ),
    fullSlide(
      uiOutput('uiArt2')
    )
  ),
  
  # venue section----
  fullSectionImage(
    menu = 'venue',
    center = TRUE,
    img = 'pg_venue.jpeg', 
    fullSlide(
      fullButtonRight(
        img(
          src = 'venue_logo.png', 
          width = '50%' 
        )
      )
    ),
    fullSlide(
      uiOutput('uiVenue')
    )
  ),
  
  # exper section----
  fullSectionImage(
    menu = 'exper',
    center = TRUE,
    img = 'exper.jpg',
    fullSlide(
      wellPanel(
        style = 'background-color:rgba(200,200,200,0.6); 
                   padding:60px; border-width:0;',  
        h1(style = 'color:blue; font-size:68px; font-family:Segoe Script',
           'Enjoy Your STAY @ Chicago'),  
        hr(),
        fluidRow(
          column(
            width = 4,
            fullButtonRight(
              actionBttn(
                inputId = 'hotels',
                label = 'Pleasant Homes',
                style = 'jelly',
                color = 'warning',
                size = 'lg',
                block = TRUE
              )
            )
          ),
          column(
            width = 4,
            fullButtonRight(
              actionBttn(
                inputId = 'rests',
                label = 'Explore Gourmets',
                style = 'jelly',
                color = 'success',
                size = 'lg',
                block = TRUE
              )
            )
          ),
          column(
            width = 4,
            fullButtonRight(
              actionBttn(
                inputId = 'attrs',
                label = 'Endless Discoveries',
                style = 'jelly',
                color = 'danger',
                size = 'lg',
                block = TRUE
              )
            )
          )
        )
      )
    ),
    fullSlide(
      uiOutput('uiExper')
    )
  ),
  
  # about section----
  fullSectionImage(
    menu = 'about',
    center = TRUE,
    img = 'team.jfif', 
    fullSlide(
      wellPanel(
        style = 'background-color:rgba(0,0,0,0); border:0px; 
                 padding-top:40vh; padding-bottom:40vh;',
        fullButtonRight(
          h1(
            style = 'color:white;font-size: 66px;font-family:Cooper Black',
            'Our Team'
          )
        )
      )
    ),
    fullSlide(
      uiOutput('uiTeam')
    )
  )
  
)


